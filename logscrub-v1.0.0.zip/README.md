# logscrub · 日志/工单脱敏器（PII Scrubber）

> 一句话：把日志、工单、报错堆栈交给外部团队之前，一条命令做掉手机号、身份证、银行卡、邮箱、明文口令、JWT、内网 IP，脱敏后还能对得上号，并附一份能交给合规看的审计报告。
> 单文件、零依赖、纯本地（Python 3.8+，只用标准库），不联网、不上传。

---

## 1. 目标用户（明确到岗位，不是"所有人"）

| 人群 | 具体场景 | 为什么会付钱 |
| --- | --- | --- |
| 乙方交付 / 外包开发（1–20 人团队） | 甲方要日志排查，要把线上报错贴进工单、微信群 | 直接贴原始日志等于违约与泄露事故；手工替换两小时还会漏 |
| 中小 SaaS / 电商的运维与技术支持 | 提工单给云厂商、CDN、支付渠道 | 工单必须附日志，法务与合规不放行明文手机号、卡号 |
| 客服与工单系统管理员 | 导出工单 CSV 给数据团队或外包标注 | 一个 CSV 几万条手机号加身份证，人工脱敏不可能 |
| 独立开发者 / 自由职业者 | 把客户环境数据、样例数据发给对方或写进文章 | 一次事故的赔偿远高于工具价格 |

共同点：**必须把数据交出去，数据里又有真实个人信息**，而他们手上没有 DLP 系统，也不想起一套。

## 2. 痛点（用户自己会说的话）

1. "日志直接发给甲方，手机号、身份证、卡号全在里面，出事我担。"
2. "手工 Ctrl+H 替换，几个 G 的日志根本干不完，替换完自己都看不懂谁是谁。"
3. "外包标注要能对上同一个用户，全替换成 `***` 就对不上了。"
4. "合规要留痕：得说清楚跑了哪些文件、替换了多少、有没有漏。"
5. "在线脱敏网站不敢用——日志本身就是要保密的东西。"

## 3. 卖点（每条都对得上一个痛点）

- **一致性令牌化**：同一 salt 下，同一个手机号在任何文件里都变成同一个 `[CN_MOBILE:24EEB3779E83]`，脱敏后仍能做关联分析；换 salt 即彻底断开关联。手工替换做不到，普通正则替换也做不到。
- **复扫即审计**：每轮脱敏后立刻再扫一遍输出，`residual_after_rescan` 必须为 0 才返回成功（非 0 直接退出码 1），并可导出 JSON 报告（Pro）交给合规或甲方。
- **幂等**：已脱敏的文件再跑一次替换数为 0，不会二次打码把令牌打坏。
- **纯本地、零依赖、零安装**：一个目录四个 `.py`，`python cli.py` 就跑，不联网、不经手第三方，可直接放进客户内网或离线机器。
- **保留可读上下文**：只打值不打键，`password="[SECRET:...]"`、`phone=[CN_MOBILE:...]` 仍能看出日志在说什么，排障不受影响。
- **7 类内置识别 + 自定义规则**：手机号、18 位身份证（按出生日期结构识别）、银行卡（Luhn / 卡 BIN）、邮箱、明文口令与 API key、JWT、内网 IPv4；Pro 可加自己的订单号、内部域名、姓名等规则。
- **授权可交付**：内置 `LICENSE_BLOB + SERIAL` 校验骨架，免费与 Pro 的分层就是代码事实，开卖时不用另写一套授权系统。

## 4. 快速开始

环境：Windows / macOS / Linux，Python 3.8+，无第三方依赖。

```powershell

cd money-lab/tools/logscrub

# 免费模式：单个文件
python cli.py scrub --in .\sample.log --out .\out

# Pro 模式：整个目录 + 审计报告（内置演示授权即可跑通链路）
python cli.py scrub --in .\logs --out .\out --report .\report.json --demo

# 用真实授权文件（纯 blob 文本，或含 serial 的 JSON）
python cli.py scrub --in .\logs --out .\out --license .\license.txt --serial LS-PRO-000123

# 只校验授权，不脱敏
python cli.py license-check --license .\license.txt --serial LS-PRO-000123

# 签发端工具（正式版只存在于你自己的服务器/内网）
python cli.py issue --serial LS-PRO-000123 --days 365 --out .\license.txt

# 全链路自检（19 项：功能 + 授权正负例）
python demo.py
```

实测输出（Pro 目录批量）：

```
授权：pro｜授权有效：pro，有效期至 2027-11-24T06:30:46Z
模式：pro    文件：3    行数：9
替换：13 处    [BANK_CARD=1  CN_ID=2  CN_MOBILE=3  EMAIL=1  IPV4=3  JWT=1  SECRET=2]
复扫残留：0 处（必须为 0 才算通过）
salt 指纹：FF098C74    耗时：11.74 ms
输出：<tmp>\pro_out
```

脱敏前后（真实输出）：

```
输入: 2024-05-11T09:12:04Z pay card=6222020200112233445 from 203.0.113.7 uid=110105199003071234
输出: 2024-05-11T09:12:04Z pay card=[BANK_CARD:9214176C3C01] from [IPV4:86DEBFE907A8] uid=[CN_ID:E1507A684B47]
```

## 5. 命令一览

| 命令 | 作用 | 授权要求 |
| --- | --- | --- |
| `scrub --in --out` | 脱敏单文件或目录 | 单文件免费 / 目录需 Pro |
| `--salt` | 令牌化盐值，同盐才能跨文件对上号（默认 `logscrub-default-salt-v1`） | 免费 |
| `--dry-run` | 只统计不落盘 | 免费 |
| `--report FILE` | 导出 JSON 审计报告 | Pro |
| `--rules FILE` | 自定义识别规则 | Pro |
| `license-check` | 校验 LICENSE_BLOB + SERIAL | - |
| `issue` | 签发 LICENSE_BLOB（演示签发端） | - |

退出码：`0` 成功 / `1` 处理失败或复扫有残留 / `3` 触达付费边界（可直接用于脚本判断是否需要升级）。

| 能力 | 免费 | Pro |
| --- | --- | --- |
| 单次文件数 | 1 个 | 不限（目录递归） |
| 单次行数 | ≤ 2000 | 不限 |
| 7 类内置识别 | 有 | 有 |
| 一致性令牌化 + 复扫 | 有 | 有 |
| 自定义规则 | 无 | 有 |
| JSON 审计报告 | 无 | 有 |

## 6. 定价建议（可直接上架用）

| 版本 | 价格 | 说明 | 依据 |
| --- | --- | --- | --- |
| 免费版 | ¥0 | 单文件、2000 行 | 足够跑通一次真实需求，形成"差一点就顺手"的升级压力 |
| 个人 Pro（年付） | **¥129 / 年** | 单机，批量 + 规则 + 报告 | 对标开发者小工具常见价格带 ¥99–199；低于一次外包小时费，决策成本极低 |
| 团队 Pro（年付） | **¥599 / 年** | 5 席，含规则模板库 | 5 席人均 ¥120，团队走对公采购，客单价 ×4.6 |
| 企业内网部署 | **¥4800 / 年起** | 私有化 + 自定义识别 + 发票合同 | 客户是"数据不能出内网"的甲方，锚点是 DLP 方案年费的零头 |
| 一次性买断（个人） | ¥399 | 永久当前大版本 | 给抗拒订阅的人一个出口，通常比年付更容易转化 |

定价逻辑：**按事故成本定价，不按代码量定价**。一次个人信息泄露的赔偿与违约远高于 ¥129，所以主推年付，同时把买断价挂在页面上降低决策门槛；团队版用席位差拉客单价；企业版只做标品私有化，不接定制开发。

## 7. 授权校验接入说明（LICENSE_BLOB + SERIAL）

### 7.1 结构

```
LICENSE_BLOB = <payload_b64url>.<signature_b64url>

payload (JSON) = {
  "format":     "logscrub-license/1",
  "serial":     "LS-PRO-000123",           // 必须与用户持有的 SERIAL 一致
  "tier":       "pro",
  "features":   ["batch", "custom_rules", "json_report", "vault"],
  "issued_at":  "2026-11-24T06:30:46Z",
  "expires_at": "2027-11-24T06:30:46Z"     // null 表示永久
}
```

### 7.2 校验流程（`license_gate.verify_license`）

1. 无 blob → `NO_LICENSE`，按免费模式运行（不报错、不拦单文件）。
2. 格式必须恰好一个 `.`，否则 `BAD_FORMAT`。
3. 验签（DEMO 用 HMAC-SHA256 常量时间比较；失败 → `BAD_SIGNATURE`）。
4. 解 payload 失败 → `BAD_PAYLOAD`。
5. SERIAL 缺失 → `SERIAL_MISSING`；与 payload 不一致 → `SERIAL_MISMATCH`（防止串用别人的授权文件）。
6. 生效时间在未来 → `NOT_YET_VALID`；已过期 → `EXPIRED`。
7. 通过 → `code=OK`，返回 `tier` / `features` / `expires_at`；只有 `ok=True` 才放行 Pro 能力（`run_scrub(is_pro=...)`）。

授权文件支持两种形态：纯 blob 文本（`license.txt`），或 `{"license_blob": "...", "serial": "..."}` 的 JSON（`license.json`）。

### 7.3 DEMO 与正式版的差别（卖之前必须看完）

- **DEMO（当前代码）**：HMAC-SHA256 加代码内置共享密钥，能验签、能防篡改、能过期、能绑序列号，**但拿到源码即可自签**。它的用途是让授权逻辑闭合、可测试，不是最终防护强度。
- **正式版替换点**（`license_gate.py` 内已标 `[REAL-INTEGRATION]`）：
  1. 签发端用 **Ed25519 私钥**对 `payload_b64` 签名，私钥只在服务端；客户端只内置公钥 PEM，把 `verify_license` 里的 HMAC 两行换成 `ed25519_verify(PUBLIC_PEM, payload_b64, sig)`。
  2. **设备绑定**：payload 增加 `machine` = 本机指纹哈希（`hash(machine-id + 网卡 MAC)`），验签后比对。
  3. **在线激活与续期**：`POST /activate {serial, machine}` 返回 blob，客户端缓存到 `%LOCALAPPDATA%/logscrub/license.json`，租期 7–30 天，带 14 天离线宽限，到期前静默刷新。
  4. **吊销**：payload 带 `license_id`，客户端每 7 天拉一次吊销名单，命中即降级为免费模式（不删数据、不罢工）。
  5. `issue` 子命令上线前从客户端移除，只保留在服务端仓库。

## 8. 自定义规则格式（Pro）

```json
{
  "version": 1,
  "rules": [
    { "kind": "ORDER_ID",      "pattern": "ORD\\d{11}" },
    { "kind": "INTERNAL_HOST", "pattern": "[a-z0-9-]+\\.corp\\.example\\.com" },
    { "kind": "CN_NAME",       "pattern": "(?<=客户：)[\\u4e00-\\u9fa5]{2,4}" }
  ]
}
```

`kind` 会成为令牌前缀（例如 `[ORDER_ID:...]`）；`pattern` 是 Python 正则，命中整段替换。内置规则优先，自定义规则补充在后，重叠区间按"靠前 + 更长"胜出。

## 9. 已知限制（诚实写在这里，也是 Pro 支持的话术）

- 只处理文本类后缀（`.log .txt .csv .json .jsonl .ndjson .yaml .yml .ini .conf .cfg .env .md .out .err .trace`），二进制文件不碰。
- 正则识别不是万能：手机号被拆成 `138 0013 8000`、姓名、地址、护照号等不保证命中——这正是"自定义规则"与后续 preset 模板的付费空间。身份证按出生日期结构识别，标签含义仅供参考（一律照打码处理，宁可多打不漏打）。
- `--salt` 一旦更换，历史令牌就无法与新文件对上号；团队使用请把 salt 固定成项目级常量。
- 令牌是基于哈希的单向映射，**不可还原**；需要保留可还原映射表的场景不在本工具范围，也正因如此它敢在内网跑。
- 不读环境变量、不联网；目录处理为单线程顺序执行（10 万行级约 0.1–1 秒，耗时见报告 `elapsed_ms`）。

## 10. 文件清单

| 文件 | 作用 |
| --- | --- |
| `cli.py` | 命令行入口：scrub / license-check / issue，退出码 0 / 1 / 3 |
| `logscrub.py` | 核心引擎：7 类识别、重叠仲裁、令牌化、复扫、审计报告 |
| `license_gate.py` | LICENSE_BLOB + SERIAL 校验骨架、签发、授权文件加载、正式接入点标注 |
| `demo.py` | 可复现 demo：19 项自检（核心功能 + 授权正负例） |
| `rules.example.json` | 自定义规则样例（Pro） |
| `README.md` | 本文档 |

## 11. 验收证据（`python demo.py` 实测，Python 3.13 / Windows）

```
[1/7] 生成 3 个样本日志：手机号 / 身份证 / 银行卡 / 邮箱 / 明文口令 / JWT / 内网 IP
  [PASS] 样本文件落盘  -> 3 files
[2/7] 免费模式边界：单文件放行、目录批量拦截
  [PASS] 免费模式单文件脱敏放行  -> exit=0
  [PASS] 免费模式目录批量被拦截  -> exit=3
[3/7] 签发演示授权（DEMO 共享密钥；正式版由服务端私钥签发）
  [PASS] DEMO LICENSE_BLOB 验签通过  -> OK / 到期 2036-11-21T06:30:45Z
[4/7] Pro 模式批量脱敏 + JSON 审计报告
  [PASS] Pro 批量脱敏退出码 0  -> exit=0
  [PASS] 处理后复扫残留为 0  -> residual=0
  [PASS] 识别出 >=6 类敏感数据  -> kinds=BANK_CARD,CN_ID,CN_MOBILE,EMAIL,IPV4,JWT,SECRET
[5/7] 一致性校验：同一敏感值跨文件映射为同一令牌
  [PASS] 跨文件同一手机号令牌一致  -> [CN_MOBILE:24EEB3779E83]
  [PASS] 原文敏感值已彻底消失  -> no plaintext in outputs
  [PASS] 非敏感字段保持原样  -> context kept
  [PASS] 重复脱敏幂等（令牌不会被二次替换）  -> replaced=0
  [PASS] 更换 salt 后令牌不可关联  -> salt isolation
[6/7] Pro 自定义规则（与 rules.example.json 同结构）
  [PASS] 自定义规则 ORDER_ID 生效  -> exit=0
  [PASS] 免费模式拒绝自定义规则  -> exit=3
[7/7] 授权负例
  [PASS] 篡改 LICENSE_BLOB -> 签名失败  -> BAD_SIGNATURE
  [PASS] 串用他人 SERIAL -> 拒绝  -> SERIAL_MISMATCH
  [PASS] 过期授权 -> 拒绝  -> 授权已于 2026-10-25T06:30:45Z 过期
  [PASS] 无授权 -> 免费模式  -> NO_LICENSE
  [PASS] 无授权批量仍被拦截  -> exit=3

==========================================================
结果：19/19 通过
ALL CHECKS PASSED
```

## 12. 下一步怎么把它变成钱（执行顺序）

1. 打包上架：`PyInstaller --onefile cli.py` 出 `logscrub.exe`，免费版直接放下载页，不需要注册。
2. 落地页只讲一件事："把日志发给别人之前，先跑一遍"，附脱敏前后对比截图与免费版下载。
3. 免费版的付费拦截文案统一，指向购买页（当前实现为 `--license` 引导 + 退出码 3）。
4. 先打 3 个渠道：外包接单社群、云厂商工单吐槽帖、合规与等保讨论群；钩子统一用"免费版能不能过你手上这份日志"。
5. 收到第一个付费客户后再接在线激活（Ed25519 加 /activate），不要提前做。
